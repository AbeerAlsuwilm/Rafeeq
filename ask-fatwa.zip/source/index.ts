import { withSupabase } from "jsr:@supabase/server@^1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

// ==========================================
// Generate E5 Embedding
// ==========================================
async function generateEmbedding(text: string): Promise<number[]> {
  const hfToken = Deno.env.get("HUGGING_FACE_TOKEN");

  if (!hfToken) {
    throw new Error("HUGGING_FACE_TOKEN is missing");
  }

  const { InferenceClient } = await import(
    "https://esm.sh/@huggingface/inference"
  );

  const hf = new InferenceClient(hfToken);

  const result = await hf.featureExtraction({
    model: "intfloat/multilingual-e5-base",
    inputs: "query: " + text,
    normalize: true,
  });

  let embedding: number[];

  if (
    Array.isArray(result) &&
    result.length > 0 &&
    Array.isArray(result[0])
  ) {
    embedding = result[0] as number[];
  } else if (
    Array.isArray(result) &&
    result.length > 0 &&
    typeof result[0] === "number"
  ) {
    embedding = result as number[];
  } else {
    throw new Error("Invalid embedding response");
  }

  if (embedding.length !== 768) {
    throw new Error(
      `Wrong embedding size: ${embedding.length}. Expected 768.`,
    );
  }

  return embedding;
}

// ==========================================
// Claude
// ==========================================
async function askClaude(
  question: string,
  context: string,
): Promise<string> {
  const claudeKey = Deno.env.get("ANTHROPIC_API_KEY");

  if (!claudeKey) {
    throw new Error("ANTHROPIC_API_KEY is missing");
  }

  const response = await fetch(
    "https://api.anthropic.com/v1/messages",
    {
      method: "POST",
      headers: {
        "x-api-key": claudeKey,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
      },
      body: JSON.stringify({
        model: "claude-sonnet-5-5",
        max_tokens: 1500,

        messages: [
          {
            role: "user",
            content: `
أنت مساعد للإجابة عن الأسئلة الشرعية.

أجب اعتمادًا فقط على المصادر الموجودة في السياق.

القواعد:
1. لا تخترع أي معلومة غير موجودة في المصادر.
2. إذا كانت المصادر غير كافية، قل إن المصادر المتاحة غير كافية.
3. ميّز بين الفتوى والحديث.
4. لا تجعل الحديث وحده فتوى أو حكمًا شرعيًا.
5. لا تنسب الحكم إلى عالم أو جهة إلا إذا كان ذلك موجودًا في المصدر.
6. لا تقل "صحيح" أو "متفق عليه" إلا إذا كانت موجودة في البيانات.
7. إذا وجدت فتوى مباشرة مرتبطة بالسؤال، أعطها الأولوية.
8. اذكر المصادر المستخدمة في نهاية الإجابة.

سؤال المستخدم:
${question}

المصادر المسترجعة:
${context}

اكتب إجابة واضحة ومختصرة باللغة العربية.
`,
          },
        ],
      }),
    },
  );

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Claude error: ${errorText}`);
  }

  const result = await response.json();

  const textParts: string[] = [];

  for (const block of result.content ?? []) {
    if (block.type === "text" && block.text) {
      textParts.push(block.text);
    }
  }

  return textParts.join("\n");
}

// ==========================================
// Backend
// ==========================================
export default {
  fetch: withSupabase(
    { auth: ["publishable", "secret"] },
    async (req, ctx) => {
      if (req.method === "OPTIONS") {
        return new Response("ok", {
          headers: corsHeaders,
        });
      }

      try {
        const body = await req.json();

        const question = body.question?.trim();
        const type = body.type ?? "all";

        if (!question) {
          return Response.json(
            { error: "اكتبي السؤال أولًا" },
            {
              status: 400,
              headers: corsHeaders,
            },
          );
        }

        // ==========================================
        // 1. Embedding
        // ==========================================
        const queryEmbedding = await generateEmbedding(question);

        // ==========================================
        // 2. البحث في الفتاوى
        // ==========================================
        let fatwas: any[] = [];

        if (type === "all" || type === "fatwas") {
          const { data, error } = await ctx.supabaseAdmin.rpc(
            "match_test_fatwas_e5",
            {
              query_embedding: queryEmbedding,
              match_threshold: 0.3,
              match_count: 5,
            },
          );

          if (error) {
            throw new Error(`Fatwa search error: ${error.message}`);
          }

          fatwas = data ?? [];
        }

        // ==========================================
        // 3. البحث في الأحاديث
        // ==========================================
        let hadiths: any[] = [];

        if (type === "all" || type === "hadiths") {
          const { data, error } = await ctx.supabaseAdmin.rpc(
            "match_hadiths",
            {
              query_embedding: queryEmbedding,
              match_count: 5,
            },
          );

          if (error) {
            throw new Error(`Hadith search error: ${error.message}`);
          }

          hadiths = data ?? [];
          console.log("HADITH SEARCH RESULT:", hadiths);
        }

        // ==========================================
        // 4. بناء Context
        // ==========================================
        const contextParts: string[] = [];

        for (const item of fatwas) {
          contextParts.push(`
[فتوى]
العنوان: ${item.title ?? ""}
السؤال: ${item.question ?? ""}
الجواب: ${item.answer ?? ""}
المصدر: ${item.source ?? ""}
الرابط: ${item.source_url ?? ""}
درجة التشابه: ${item.similarity ?? ""}
`);
        }

        for (const item of hadiths) {
          contextParts.push(`
[حديث]
العنوان: ${item.title ?? ""}
نص الحديث: ${item.hadith_text ?? ""}
الشرح: ${item.explanation ?? ""}
الدرجة: ${item.grade ?? ""}
التخريج: ${item.takhrij ?? ""}
الرابط: ${item.link ?? ""}
درجة التشابه: ${item.similarity ?? ""}
`);
        }

        const context = contextParts.join("\n");

        // ==========================================
        // 5. Claude
        // ==========================================
        const answer = await askClaude(question, context);

        // ==========================================
        // 6. Sources
        // ==========================================
        const sources = [
          ...fatwas.map((item) => ({
            type: "fatwa",
            title: item.title,
            source: item.source,
            url: item.source_url,
            similarity: item.similarity,
          })),

          ...hadiths.map((item) => ({
            type: "hadith",
            title: item.title,
            url: item.link,
            grade: item.grade,
            similarity: item.similarity,
          })),
        ];

        return Response.json(
          {
            success: true,
            question,
            answer,
            sources,
          },
          {
            headers: corsHeaders,
          },
        );
      } catch (error) {
        console.error(error);

        return Response.json(
          {
            success: false,
            error: error instanceof Error
              ? error.message
              : "حدث خطأ غير معروف",
          },
          {
            status: 500,
            headers: corsHeaders,
          },
        );
      }
    },
  ),
};